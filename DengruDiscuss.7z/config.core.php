<?php
/**
 * @name Config.core
 *
 * DengruDiscuss
 * -------------
 * @author Dennis Grundelius
 *
 */

// Paths
define('CORE_PATH', dirname(__FILE__) . '/core');
define('TPL_PATH', CORE_PATH . '/tpl');
define('MODELS_PATH', CORE_PATH . '/models');
define('LIBS_PATH', CORE_PATH . '/libs');

// Settings
define('CORE_PROTOCOL', 'http://');
define('CORE_HOSTNAME', 'dengrudiscuss');
define('CORE_URL', CORE_PROTOCOL . CORE_HOSTNAME);

define('SITE_NAME', 'DengruDiscuss');

// Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'dengrudiscuss');
define('DB_USER', 'dengru21');
define('DB_PASS', 'sBXzzdxf9heEXFtW');

define('SQLITE_FILE', './test.sdb');// For Platforms Running SQLITE instead of MySQL

// Debugging
define('DEBUG', true);

?>