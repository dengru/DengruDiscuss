			<div id="admin-index">
				<div id="breadcrumbs">
					<p>Administration</p>
				</div>
				
				<div class="admin-menu">
					<nav class="primaryNav left">
					 	<ul class="group horizList">
					 		<li><a href="?q=admin">Admin Home</a></li>
					 		<li><a href="<?php echo CORE_URL . '/index.php?q=admin&a=categories';?>">Categories</a></li>
 						 	<li><a href="<?php echo CORE_URL . '/index.php?q=admin&a=new-category';?>">New Category</a></li>
					 	</ul>
					</nav>
				</div>
				
				<h1>DengruDiscuss Administration Section</h1>
				
				<p>Welcome to the administration section of the DengruDiscuss discussion board.
				The DengruDiscuss discussion board features a truly easy navigated suite for administrators to manage their discussion board. In this suite you are able to create, manage and remove any desireable from the discussion board, for instance, a user, a category.
				
				Launch, promote and improve your precious website more easily with our wonderful DengruDiscuss software together with it's powerfull administration suite.</p>
				
			</div>