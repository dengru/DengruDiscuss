			<div>
				<p>You were successfully logged out, you will be redirected within 5 seconds.</p>
			</div>