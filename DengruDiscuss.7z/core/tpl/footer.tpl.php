</div>
	</div>
	
	<div class="footer-container">
		<footer class="wrapper">
			<h4>&copy; DengruDiscuss 2014 - 2018, All Rights Reserved.</h4>
			<p>Developed by <strong>Dennis Grundelius</strong></p>
		</footer>
	</div>
	
	
	<script src="assets/static/js/modernizr-2.6.2.js"></script>
</body>
</html>